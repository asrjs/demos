export class AudioSegmentProcessor {
    constructor(options = {}) {
        this.options = {
            sampleRate: 16000,
            windowSize: 256,          // Smaller window for better resolution
            minSpeechDuration: 0.1,   // Shorter to catch brief sounds
            maxSilenceInSpeech: 0.3,  // Allow more silence within speech
            minSilenceBetween: 0.3,   // Shorter silence between words
            mergeThreshold: 0.8,      // Less aggressive merging
            energyThreshold: 0.02,    // Lower base threshold
            energyScale: 1,           // No scaling
            contextWindow: 0.1,       // Context window
            logger: console.log,      // Default to console.log
            ...options
        };

        this.speechStart = null;
        this.lastSpeechEnd = null;
        this.energyHistory = [];
        this.silenceCounter = 0;
        this.pendingSegments = [];
        this.energyAverage = 0;
        
        // Add debug counters
        this.debugStats = {
            totalFrames: 0,
            speechFrames: 0,
            segmentsCreated: 0,
            segmentsMerged: 0
        };

        // Add state tracking
        this.state = {
            currentState: 'silence',  // 'silence' or 'speech'
            stateStartTime: 0,
            currentEnergy: 0,
            silenceDuration: 0,
            speechDuration: 0
        };
    }

    log(message, data = null) {
        if (data) {
            this.options.logger(`${message}: ${JSON.stringify(data)}`);
        } else {
            this.options.logger(message);
        }
    }

    calculateEnergy(window) {
        if (window.length === 0) return 0;
        
        const energy = Math.sqrt(
            window.reduce((sum, sample) => sum + sample * sample, 0) / window.length
        ) * this.options.energyScale;
        
        // Update background energy with longer history
        if (this.energyHistory.length > 50) {
            this.energyHistory.shift();
        }
        this.energyHistory.push(energy);
        
        // Use median for more stable background estimation
        const sortedEnergies = [...this.energyHistory].sort((a, b) => a - b);
        this.energyAverage = sortedEnergies[Math.floor(sortedEnergies.length / 2)];

        this.log('Energy calculation', {
            energy: energy.toFixed(5),
            average: this.energyAverage.toFixed(5),
            historyLength: this.energyHistory.length
        });
        
        return energy;
    }

    isSpeech(energy) {
        this.debugStats.totalFrames++;
        const dynamicThreshold = Math.max(
            this.options.energyThreshold,
            this.energyAverage * 1.1
        );
        
        this.log('Speech detection', {
            energy: energy.toFixed(5),
            threshold: this.options.energyThreshold.toFixed(5),
            dynamicThreshold: dynamicThreshold.toFixed(5),
            background: this.energyAverage.toFixed(5),
            isSpeech: energy > dynamicThreshold
        });
        
        const isSpeech = energy > dynamicThreshold;
        if (isSpeech) this.debugStats.speechFrames++;
        
        return isSpeech;
    }

    processAudioData(audioData, currentTime) {
        this.log('Starting audio processing', {
            dataLength: audioData.length,
            currentTime,
            initialState: this.state.currentState
        });

        // Calculate energy levels with detailed logging
        const energies = [];
        let avgEnergy = 0;
        
        for (let i = 0; i < audioData.length; i += this.options.windowSize) {
            const window = audioData.slice(i, Math.min(i + this.options.windowSize, audioData.length));
            const energy = this.calculateEnergy(window);
            const timePoint = currentTime + (i / this.options.sampleRate);
            avgEnergy += energy;
            
            energies.push({ energy, position: i, time: timePoint });
        }
        avgEnergy /= energies.length;

        this.log('Buffer energy stats', {
            average: avgEnergy.toFixed(5),
            max: Math.max(...energies.map(e => e.energy)).toFixed(5),
            min: Math.min(...energies.map(e => e.energy)).toFixed(5),
            threshold: this.options.energyThreshold
        });

        // Process energy levels to detect state transitions
        const segments = [];
        
        energies.forEach(({ energy, position, time }) => {
            const isSpeech = this.isSpeech(energy);
            this.state.currentEnergy = energy;

            // Handle state transitions
            if (this.state.currentState === 'silence' && isSpeech) {
                // Silence -> Speech transition
                const silenceDuration = time - this.state.stateStartTime;
                this.log('🔇 Silence ended', {
                    duration: silenceDuration.toFixed(2) + 's',
                    startTime: this.state.stateStartTime.toFixed(2),
                    endTime: time.toFixed(2),
                    avgEnergy: this.state.currentEnergy.toFixed(5)
                });

                this.state.currentState = 'speech';
                this.state.stateStartTime = time;
                this.speechStart = position;

            } else if (this.state.currentState === 'speech' && !isSpeech) {
                this.silenceCounter += this.options.windowSize;
                
                if (this.silenceCounter > this.options.minSilenceBetween * this.options.sampleRate) {
                    // Speech -> Silence transition
                    const speechDuration = time - this.state.stateStartTime;
                    this.log('🗣️ Speech ended', {
                        duration: speechDuration.toFixed(2) + 's',
                        startTime: this.state.stateStartTime.toFixed(2),
                        endTime: time.toFixed(2),
                        avgEnergy: this.state.currentEnergy.toFixed(5)
                    });

                    if (speechDuration > this.options.minSpeechDuration) {
                        // Create speech segment
                        const segment = {
                            startTime: this.state.stateStartTime,
                            endTime: time,
                            audioData: new Float32Array(
                                audioData.slice(
                                    this.speechStart,
                                    position + this.options.windowSize
                                )
                            )
                        };
                        segments.push(segment);
                        
                        this.log('📊 Created segment', {
                            start: segment.startTime.toFixed(2),
                            end: segment.endTime.toFixed(2),
                            duration: (segment.endTime - segment.startTime).toFixed(2),
                            samples: segment.audioData.length
                        });
                    }

                    this.state.currentState = 'silence';
                    this.state.stateStartTime = time;
                    this.speechStart = null;
                    this.silenceCounter = 0;
                }
            }
        });

        // Log final state
        this.log('Buffer processing complete', {
            finalState: this.state.currentState,
            segmentsCreated: segments.length,
            currentEnergy: this.state.currentEnergy.toFixed(5),
            avgEnergy: avgEnergy.toFixed(5)
        });

        return segments;
    }

    reset() {
        this.speechStart = null;
        this.lastSpeechEnd = null;
        this.energyHistory = [];
        this.silenceCounter = 0;
        this.pendingSegments = [];
        this.energyAverage = 0;
    }

    setThreshold(threshold) {
        this.options.energyThreshold = threshold;
    }

    setSilenceLength(length) {
        this.options.minSilenceBetween = length;
        this.log('Updated silence length', length);
    }
} 