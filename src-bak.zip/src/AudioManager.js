import { AudioSegmentProcessor } from './AudioSegmentProcessor';
import { SpeechSegment } from './SpeechSegment';

export class AudioManager {
    constructor(worker, options = {}) {
        this.options = {
            sampleRate: 16000,
            maxAudioLength: 30,
            processingInterval: 500,
            bufferWindow: 15,
            energyThreshold: 0.02,
            minSpeechDuration: 0.1,
            minSilenceBetween: 0.3,
            logger: console.log,
            audioProcessor: null,
            ...options
        };

        this.worker = worker;
        this.audioProcessor = this.options.audioProcessor;
        if (!this.audioProcessor) {
            throw new Error('AudioProcessor is required');
        }

        // State
        this.segments = [];
        this.isProcessing = false;
        this.lastProcessedTime = 0;
        this.currentLanguage = 'tr';

        // Callbacks
        this.onSegmentsUpdate = null;
        this.onTranscriptionUpdate = null;
        this.onProcessingStateChange = null;
    }

    setCallbacks({
        onSegmentsUpdate,
        onTranscriptionUpdate,
        onProcessingStateChange
    }) {
        this.onSegmentsUpdate = onSegmentsUpdate;
        this.onTranscriptionUpdate = onTranscriptionUpdate;
        this.onProcessingStateChange = onProcessingStateChange;
    }

    async processAudioBuffer(audioBuffer) {
        if (this.isProcessing) {
            this.options.logger('Skipping - currently processing');
            return;
        }

        try {
            const audio = audioBuffer.getChannelData(0);
            
            this.options.logger('Processing audio window', {
                duration: (audio.length / this.options.sampleRate).toFixed(2) + 's',
                samples: audio.length
            });

            // Process audio for speech segments
            const newSegments = this.audioProcessor
                .processAudioData(audio, this.lastProcessedTime)
                .map(segmentData => new SpeechSegment(segmentData));

            this.options.logger('Speech detection results', {
                segmentsFound: newSegments.length,
                segments: newSegments.map(s => ({
                    start: s.startTime.toFixed(2),
                    end: s.endTime.toFixed(2),
                    duration: s.getDuration().toFixed(2),
                    energy: s.energy.toFixed(3)
                }))
            });

            if (newSegments.length > 0) {
                this.segments = [...this.segments, ...newSegments];
                this.onSegmentsUpdate?.(this.segments);

                // Find unprocessed speech segment
                const unprocessedSpeech = newSegments.find(s => !s.isProcessed && !s.isSilence);
                if (unprocessedSpeech) {
                    this.isProcessing = true;
                    this.onProcessingStateChange?.(true);

                    this.worker.postMessage({
                        type: 'generate',
                        data: {
                            audio: unprocessedSpeech.audioData,
                            language: this.currentLanguage,
                            segmentId: this.segments.length - 1
                        }
                    });
                }
            }

        } catch (error) {
            this.options.logger('Error processing audio: ' + error.message);
        }
    }

    handleWorkerMessage(message) {
        switch (message.status) {
            case 'complete':
                this.isProcessing = false;
                this.onProcessingStateChange?.(false);
                
                if (message.segmentId !== undefined) {
                    this.segments = this.segments.map((seg, idx) => 
                        idx === message.segmentId 
                            ? { ...seg, isProcessed: true, transcription: message.output }
                            : seg
                    );
                    this.onSegmentsUpdate?.(this.segments);
                }
                
                this.onTranscriptionUpdate?.(message.output);
                break;
        }
    }

    setLanguage(language) {
        this.currentLanguage = language;
    }

    setThreshold(threshold) {
        this.audioProcessor.setThreshold(threshold);
    }

    setSilenceLength(length) {
        this.audioProcessor.setSilenceLength(length);
    }

    reset() {
        this.segments = [];
        this.lastProcessedTime = 0;
        this.isProcessing = false;
        this.audioProcessor.reset();
        this.onSegmentsUpdate?.(this.segments);
    }
} 