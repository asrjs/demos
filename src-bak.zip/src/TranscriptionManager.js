export class TranscriptionManager {
    constructor(worker, options = {}) {
        this.worker = worker;
        this.options = {
            sampleRate: 16000,
            maxAudioLength: 30,
            processingInterval: 1000,  // Process every 1 second
            ...options
        };

        this.segments = [];
        this.isProcessing = false;
        this.lastProcessedTime = 0;
        this.onSegmentsUpdate = null;
        this.onTranscriptionUpdate = null;
        this.onProcessingStateChange = null;
    }

    setCallbacks({
        onSegmentsUpdate,
        onTranscriptionUpdate,
        onProcessingStateChange
    }) {
        this.onSegmentsUpdate = onSegmentsUpdate;
        this.onTranscriptionUpdate = onTranscriptionUpdate;
        this.onProcessingStateChange = onProcessingStateChange;
    }

    async processAudioBuffer(audioBuffer, currentTime) {
        if (this.isProcessing) {
            this.options.logger('Skipping due to processing');
            return;
        }

        const audio = audioBuffer.getChannelData(0);
        this.options.logger('Processing audio in TranscriptionManager', {
            audioLength: audio.length,
            lastProcessedTime: this.lastProcessedTime,
            hasAudioProcessor: !!this.audioProcessor
        });

        const newAudioStart = Math.floor(this.lastProcessedTime * this.options.sampleRate);
        const newAudio = audio.slice(newAudioStart);

        this.options.logger('TranscriptionManager processing', {
            audioLength: audio.length,
            newAudioStart,
            newAudioLength: newAudio.length,
            lastProcessedTime: this.lastProcessedTime
        });

        if (newAudio.length > 0) {
            console.group('Audio Processing');
            console.log('Processing new audio chunk:', {
                length: newAudio.length,
                startTime: this.lastProcessedTime,
                currentTime
            });

            // Get speech segments
            const newSegments = this.audioProcessor
                .processAudioData(newAudio, this.lastProcessedTime)
                .map(segmentData => new SpeechSegment(segmentData));

            this.options.logger('Segments detected', {
                count: newSegments.length,
                segments: newSegments.map(s => ({
                    start: s.startTime.toFixed(2),
                    end: s.endTime.toFixed(2),
                    duration: s.getDuration().toFixed(2),
                    energy: s.energy.toFixed(3)
                }))
            });

            if (newSegments.length > 0) {
                console.log('🎙️ New Speech Segments:', newSegments.map(s => ({
                    start: s.startTime.toFixed(2) + 's',
                    end: s.endTime.toFixed(2) + 's',
                    duration: s.getDuration().toFixed(2) + 's',
                    energy: s.energy.toFixed(3)
                })));
                
                this.segments = [...this.segments, ...newSegments];
                this.onSegmentsUpdate?.(this.segments);

                const unprocessedSpeech = newSegments.find(s => !s.isProcessed && !s.isSilence);
                if (unprocessedSpeech) {
                    console.log('🔄 Processing segment:', {
                        start: unprocessedSpeech.startTime.toFixed(2) + 's',
                        end: unprocessedSpeech.endTime.toFixed(2) + 's',
                        duration: unprocessedSpeech.getDuration().toFixed(2) + 's',
                        energy: unprocessedSpeech.energy.toFixed(3)
                    });
                    
                    this.isProcessing = true;
                    this.onProcessingStateChange?.(true);

                    this.worker.postMessage({
                        type: 'generate',
                        data: {
                            audio: unprocessedSpeech.audioData,
                            language: this.currentLanguage,
                            segmentId: this.segments.length - 1
                        }
                    });
                }
            } else {
                console.log('No new speech segments detected');
            }

            console.groupEnd();
            this.lastProcessedTime = audio.length / this.options.sampleRate;
        }
    }

    handleWorkerMessage(message) {
        switch (message.status) {
            case 'complete':
                this.isProcessing = false;
                this.onProcessingStateChange?.(false);
                
                // Update segment transcription
                if (message.segmentId !== undefined) {
                    this.segments = this.segments.map((seg, idx) => 
                        idx === message.segmentId 
                            ? { ...seg, isProcessed: true, transcription: message.output }
                            : seg
                    );
                    this.onSegmentsUpdate?.(this.segments);
                }
                
                // Update transcription text
                this.onTranscriptionUpdate?.(message.output);
                break;
        }
    }

    setAudioProcessor(processor) {
        this.audioProcessor = processor;
    }

    setLanguage(language) {
        this.currentLanguage = language;
    }

    reset() {
        this.segments = [];
        this.lastProcessedTime = 0;
        this.isProcessing = false;
        this.onSegmentsUpdate?.(this.segments);
    }
} 